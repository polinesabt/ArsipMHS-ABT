<?php
require_once __DIR__ . '/../../config/cors.php';



if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Load environment variables dari .env.local
require_once __DIR__ . '/../../config/env.php';
require_once __DIR__ . '/../../config/database.php';

// ========== JWT Helper Functions ==========
define('JWT_SECRET', getenv('JWT_SECRET') ?: 'your-super-secret-jwt-key-change-in-production');
define('JWT_ALGORITHM', getenv('JWT_ALGORITHM') ?: 'HS256');
define('JWT_EXPIRATION', getenv('JWT_EXPIRATION') ?: 86400); // 24 hours

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
    return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', 4 - strlen($data) % 4));
}

function generate_jwt($payload) {
    $header = ['alg' => JWT_ALGORITHM, 'typ' => 'JWT'];
    $payload['iat'] = time();
    $payload['exp'] = time() + JWT_EXPIRATION;
    
    $header_encoded = base64url_encode(json_encode($header));
    $payload_encoded = base64url_encode(json_encode($payload));
    $signature = base64url_encode(hash_hmac('sha256', 
        $header_encoded . '.' . $payload_encoded, 
        JWT_SECRET, 
        true
    ));
    
    return $header_encoded . '.' . $payload_encoded . '.' . $signature;
}

// ========== Login Logic ==========
try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['username']) || !isset($input['password'])) {
        throw new Exception('Username dan password diperlukan');
    }
    
    $username = trim($input['username']);
    $password = $input['password'];
    $role = isset($input['role']) ? trim($input['role']) : null;
    
    $user = null;
    $studentData = null;
    
    if ($role === 'student') {
        // Try login by NIM (student identifier)
        $stmt = $pdo->prepare('
            SELECT 
                u.id AS user_id, u.username, u.nama AS user_nama, u.role, u.password_hash,
                s.id AS student_id, s.nim, s.nama AS student_nama, s.jurusan, s.prodi, s.status,
                s.tahun_masuk, s.tahun_lulus, s.email, s.no_hp, s.alamat, s.has_credentials, s.last_login AS student_last_login,
                s.created_at AS student_created_at, s.updated_at AS student_updated_at
            FROM students s
            JOIN users u ON s.user_id = u.id
            WHERE s.nim = ? AND u.is_active = 1
            LIMIT 1
        ');
        $stmt->execute([$username]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            $user = [
                'id' => $row['user_id'],
                'username' => $row['username'],
                'nama' => $row['user_nama'],
                'role' => $row['role'],
                'password_hash' => $row['password_hash']
            ];
            $studentData = [
                'id' => $row['student_id'],
                'nim' => $row['nim'],
                'nama' => $row['student_nama'],
                'jurusan' => $row['jurusan'],
                'prodi' => $row['prodi'],
                'status' => $row['status'],
                'tahun_masuk' => $row['tahun_masuk'],
                'tahun_lulus' => $row['tahun_lulus'],
                'email' => $row['email'],
                'no_hp' => $row['no_hp'],
                'alamat' => $row['alamat'],
                'has_credentials' => (bool)$row['has_credentials'],
                'last_login' => $row['student_last_login'],
                'created_at' => $row['student_created_at'],
                'updated_at' => $row['student_updated_at']
            ];
        }
        
        // Fallback: login by username in users table (if NIM not found)
        if (!$user) {
            $stmt = $pdo->prepare('SELECT id, username, nama, role, password_hash FROM users WHERE username = ? AND role = ? AND is_active = 1');
            $stmt->execute([$username, 'student']);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                $stmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ?');
                $stmt->execute([$user['id']]);
                $studentData = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            }
        }
    } else if ($role === 'admin') {
        $stmt = $pdo->prepare('SELECT id, username, nama, role, password_hash FROM users WHERE username = ? AND role = ? AND is_active = 1');
        $stmt->execute([$username, 'admin']);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        // Default behavior: lookup by username regardless of role
        $stmt = $pdo->prepare('SELECT id, username, nama, role, password_hash FROM users WHERE username = ? AND is_active = 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // User tidak ditemukan
    if (!$user) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Username atau password salah'
        ]);
        exit();
    }
    
    // Verify password dengan bcrypt
    if (!password_verify($password, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Username atau password salah'
        ]);
        exit();
    }
    
    // Generate JWT token
    $token_payload = [
        'sub' => $user['id'],
        'username' => $user['username'],
        'role' => $user['role']
    ];
    $token = generate_jwt($token_payload);
    
    // Update last_login timestamp
    $stmt = $pdo->prepare('UPDATE users SET last_login = NOW() WHERE id = ?');
    $stmt->execute([$user['id']]);
    
    if ($user['role'] === 'student') {
        $stmt = $pdo->prepare('UPDATE students SET last_login = NOW() WHERE user_id = ?');
        $stmt->execute([$user['id']]);
    }
    
    // Success response dengan token
    echo json_encode([
        'success' => true,
        'data' => [
            'token' => $token,
            'jwt' => $token,
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'nama' => $user['nama'],
                'role' => $user['role'],
                'student' => $studentData
            ]
        ],
        'message' => 'Login berhasil'
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
