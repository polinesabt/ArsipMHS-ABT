<?php
/**
 * CORS Configuration
 * 
 * Untuk production, ganti ALLOWED_ORIGINS dengan domain production Anda
 */

// Load environment untuk production origin
require_once __DIR__ . '/env.php';
$allowedOrigin = getenv('ALLOWED_ORIGIN') ?: '*';

// Development: Allow all origins
// Production: Set specific origin
if ($allowedOrigin === '*' || empty($allowedOrigin)) {
    // Development mode - allow all
    header('Access-Control-Allow-Origin: *');
} else {
    // Production mode - specific origin
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if (in_array($origin, explode(',', $allowedOrigin))) {
        header("Access-Control-Allow-Origin: $origin");
    }
}

header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 86400'); // 24 hours

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Load security headers (only in production)
if (getenv('APP_ENV') === 'production') {
    require_once __DIR__ . '/security.php';
    setSecurityHeaders();
}
?>
