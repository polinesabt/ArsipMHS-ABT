<?php
/**
 * Environment Loader untuk PHP Backend
 * Prioritas: .env (production) -> .env.production -> .env.local (development)
 */

$rootDir = __DIR__ . '/../../..';
$envFile = file_exists($rootDir . '/.env')
    ? $rootDir . '/.env'
    : (file_exists($rootDir . '/.env.production')
        ? $rootDir . '/.env.production'
        : $rootDir . '/.env.local');

if (!file_exists($envFile)) {
    throw new Exception("File .env tidak ditemukan. Copy .env.example ke .env atau .env.local");
}

$lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

foreach ($lines as $line) {
    // Skip comments
    if (strpos(trim($line), '#') === 0) {
        continue;
    }

    // Parse LINE
    if (strpos($line, '=') !== false) {
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        
        // Remove quotes if present
        if ((strpos($value, '"') === 0 && strrpos($value, '"') === strlen($value) - 1) ||
            (strpos($value, "'") === 0 && strrpos($value, "'") === strlen($value) - 1)) {
            $value = substr($value, 1, -1);
        }
        
        // Set environment variable
        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
}
